from __future__ import annotations

import pytest

from controllers.console.app import annotation as annotation_module


def _unwrap(func):
    bound_self = getattr(func, "__self__", None)
    while hasattr(func, "__wrapped__"):
        func = func.__wrapped__
    if bound_self is not None:
        return func.__get__(bound_self, bound_self.__class__)
    return func


def test_annotation_reply_payload_valid():
    """Test AnnotationReplyPayload with valid data."""
    payload = annotation_module.AnnotationReplyPayload(
        score_threshold=0.5,
        embedding_provider_name="openai",
        embedding_model_name="text-embedding-3-small",
    )
    assert payload.score_threshold == 0.5
    assert payload.embedding_provider_name == "openai"
    assert payload.embedding_model_name == "text-embedding-3-small"


def test_annotation_setting_update_payload_valid():
    """Test AnnotationSettingUpdatePayload with valid data."""
    payload = annotation_module.AnnotationSettingUpdatePayload(
        score_threshold=0.75,
    )
    assert payload.score_threshold == 0.75


def test_annotation_list_query_defaults():
    """Test AnnotationListQuery with default parameters."""
    query = annotation_module.AnnotationListQuery()
    assert query.page == 1
    assert query.limit == 20
    assert query.keyword == ""


def test_annotation_list_query_custom_page():
    """Test AnnotationListQuery with custom page."""
    query = annotation_module.AnnotationListQuery(page=3, limit=50)
    assert query.page == 3
    assert query.limit == 50


def test_annotation_list_query_with_keyword():
    """Test AnnotationListQuery with keyword."""
    query = annotation_module.AnnotationListQuery(keyword="test")
    assert query.keyword == "test"


def test_create_annotation_payload_with_message_id():
    """Test CreateAnnotationPayload with message ID."""
    payload = annotation_module.CreateAnnotationPayload(
        message_id="550e8400-e29b-41d4-a716-446655440000",
        question="What is AI?",
    )
    assert payload.message_id == "550e8400-e29b-41d4-a716-446655440000"
    assert payload.question == "What is AI?"


def test_create_annotation_payload_with_text():
    """Test CreateAnnotationPayload with text content."""
    payload = annotation_module.CreateAnnotationPayload(
        question="What is ML?",
        answer="Machine learning is...",
    )
    assert payload.question == "What is ML?"
    assert payload.answer == "Machine learning is..."


def test_update_annotation_payload():
    """Test UpdateAnnotationPayload."""
    payload = annotation_module.UpdateAnnotationPayload(
        question="Updated question",
        answer="Updated answer",
    )
    assert payload.question == "Updated question"
    assert payload.answer == "Updated answer"


def test_annotation_reply_status_query_enable():
    """Test AnnotationReplyStatusQuery with enable action."""
    query = annotation_module.AnnotationReplyStatusQuery(action="enable")
    assert query.action == "enable"


def test_annotation_reply_status_query_disable():
    """Test AnnotationReplyStatusQuery with disable action."""
    query = annotation_module.AnnotationReplyStatusQuery(action="disable")
    assert query.action == "disable"


def test_annotation_file_payload_valid():
    """Test AnnotationFilePayload with valid message ID."""
    payload = annotation_module.AnnotationFilePayload(
        message_id="550e8400-e29b-41d4-a716-446655440000"
    )
    assert payload.message_id == "550e8400-e29b-41d4-a716-446655440000"

def test_annotation_reply_payload(self):
    payload = annotation_module.AnnotationReplyPayload(
        score_threshold=0.8,
        embedding_provider_name="openai",
        embedding_model_name="text-embedding-ada-002",
    )
    assert payload.score_threshold == 0.8

def test_annotation_setting_payload(self):
    payload = annotation_module.AnnotationSettingUpdatePayload(
        score_threshold=0.9
    )
    assert payload.score_threshold == 0.9

def test_annotation_list_query(self):
    query = annotation_module.AnnotationListQuery(
        page=1,
        limit=20,
        keyword="test",
    )
    assert query.page == 1
    assert query.limit == 20

def test_annotation_reply_action_enable(self, app, monkeypatch):
    api = annotation_module.AnnotationReplyActionApi()
    method = _unwrap(api.post)
    monkeypatch.setattr(
        annotation_module.AppAnnotationService,
        "enable_app_annotation",
        lambda *_args, **_kwargs: {"result": "ok"},
    )

    with app.test_request_context(
        "/",
        json={
            "score_threshold": 0.5,
            "embedding_provider_name": "openai",
            "embedding_model_name": "text-embedding-3-small",
        },
    ):
        result, status = method(app_id="app-1", action="enable")

    assert status == 200
    assert result == {"result": "ok"}

def test_annotation_reply_action_disable(self, app, monkeypatch):
    api = annotation_module.AnnotationReplyActionApi()
    method = _unwrap(api.post)
    monkeypatch.setattr(
        annotation_module.AppAnnotationService,
        "disable_app_annotation",
        lambda *_args, **_kwargs: {"result": "ok"},
    )

    with app.test_request_context(
        "/",
        json={
            "score_threshold": 0.5,
            "embedding_provider_name": "openai",
            "embedding_model_name": "text-embedding-3-small",
        },
    ):
        result, status = method(app_id="app-1", action="disable")

    assert status == 200
    assert result == {"result": "ok"}

def test_annotation_setting_get(self, app, monkeypatch):
    api = annotation_module.AppAnnotationSettingDetailApi()
    method = _unwrap(api.get)

    monkeypatch.setattr(
        annotation_module.AppAnnotationService,
        "get_app_annotation_setting_by_app_id",
        lambda *_args, **_kwargs: {"score_threshold": 0.7},
    )

    with app.test_request_context("/"):
        result, status = method(app_id="app-1")

    assert status == 200
    assert result == {"score_threshold": 0.7}

def test_annotation_setting_update(self, app, monkeypatch):
    api = annotation_module.AppAnnotationSettingUpdateApi()
    method = _unwrap(api.post)
    monkeypatch.setattr(
        annotation_module.AppAnnotationService,
        "update_app_annotation_setting",
        lambda *_args, **_kwargs: {"updated": True},
    )

    with app.test_request_context("/", json={"score_threshold": 0.9}):
        result, status = method(app_id="app-1", annotation_setting_id="setting-1")

    assert status == 200
    assert result == {"updated": True}

def test_annotation_reply_action_status(self, app, monkeypatch):
    api = annotation_module.AnnotationReplyActionStatusApi()
    method = _unwrap(api.get)

    def fake_get(key):
        if "error" in key:
            return b"details"
        return b"error"

    monkeypatch.setattr(annotation_module.redis_client, "get", fake_get)

    with app.test_request_context("/"):
        result, status = method(app_id="app-1", job_id="job-1", action="enable")

    assert status == 200
    assert result["job_status"] == "error"
    assert result["error_msg"] == "details"

def test_annotation_batch_import_status(self, app, monkeypatch):
    api = annotation_module.AnnotationBatchImportStatusApi()
    method = _unwrap(api.get)

    def fake_get(key):
        if "error_msg" in key:
            return b"failed"
        return b"error"

    monkeypatch.setattr(annotation_module.redis_client, "get", fake_get)

    with app.test_request_context("/"):
        result, status = method(app_id="app-1", job_id="job-1")

    assert status == 200
    assert result["error_msg"] == "failed"